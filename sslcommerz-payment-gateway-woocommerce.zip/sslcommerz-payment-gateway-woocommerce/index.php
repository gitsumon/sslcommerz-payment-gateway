<?php
/*
Plugin Name: WooCommerce WMB SSLCommerz Payment Gateway
Plugin URI: 
Description: WMB SSLCommerz Payment gateway for woocommerce
Version: 1.0
Author: Asad
Author URI: https://github.com/gitsumon
*/
add_action('plugins_loaded', 'woocommerce_wmb_sslcommerz_init', 0);
function woocommerce_wmb_sslcommerz_init(){
	if(!class_exists('WC_Payment_Gateway')) return;

	class WC_WMB_SSLCommerz extends WC_Payment_Gateway{
		public function __construct(){
			$this -> id = 'wmb_sslcommerz';
			$this->icon = apply_filters('woocommerce_sslcommerz_icon', plugins_url( 'images/SSLCommerz.png' , __FILE__ ) );
			$this -> medthod_title = 'WMB SSLCommerz';
			$this -> has_fields = false;

			$this -> init_form_fields();
			$this -> init_settings();

			$this -> title = $this -> settings['title'];
			$this -> description = $this -> settings['description'];
			$this -> store_id = $this -> settings['store_id'];
			$this -> store_pass = $this -> settings['store_pass'];
			$this -> redirect_success_page_id = $this -> settings['redirect_success_page_id'];
			$this -> redirect_fail_page_id = $this -> settings['redirect_fail_page_id'];
			$this -> redirect_cancel_page_id = $this -> settings['redirect_cancel_page_id'];
			$this -> liveurl = $this -> settings['redirect_url'];

			$this -> msg['message'] = "";
			$this -> msg['class'] = "";
			  
			add_action( 'woocommerce_api_wc_wmb_sslcommerz', array( $this, 'check_WMB_SSLCommerz_response' ) );
			  
			if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
				add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( &$this, 'process_admin_options' ) );
			} else {
				add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) );
			}
			add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ) ); 
		}
		function init_form_fields(){
			$this -> form_fields = array(
				'enabled' => array(
					'title' => __('Enable/Disable', 'SSLCommerz'),
					'type' => 'checkbox',
					'label' => __('Enable WMB SSLCommerz Payment Module.', 'SSLCommerz'),
					'default' => 'no'),
				'title' => array(
					'title' => __('Title:', 'SSLCommerz'),
					'type'=> 'text',
					'description' => __('This controls the title which the user sees during checkout.', 'SSLCommerz'),
					'default' => __('WMB SSLCommerz Debit/Credit Card Payment', 'SSLCommerz')),
				'description' => array(
					'title' => __('Description:', 'SSLCommerz'),
					'type' => 'textarea',
					'description' => __('This controls the description which the user sees during checkout.', 'SSLCommerz'),
					'default' => __('Pay securely by Credit or Debit card or internet banking through WMB SSLCommerz Secure Servers.', 'SSLCommerz')),
				'store_id' => array(
					'title' => __('Store ID', 'SSLCommerz'),
					'type' => 'text',
					'description' => __('This id(USER ID) available at "Generate Working Key" of "Settings and Options at WMB SSLCommerz."')),
				'store_pass' => array(
					'title' => __('Store Password', 'SSLCommerz'),
					'type' => 'password',
					'description' => __('This id(USER PASSWORD) available at "Generate Working Key" of "Settings and Options at WMB SSLCommerz."')),
				'redirect_url' => array(
					'title' => __('Redirection URL', 'SSLCommerz'),
					'type' => 'text',
					'description' => __('This is for payment Redirection URL "Live/Test"')),
				'redirect_success_page_id' => array(
					'title' => __('Success Page'),
					'type' => 'select',
					'options' => $this -> get_pages('Select Page'),
					'description' => "URL of success page"
				),
				'redirect_fail_page_id' => array(
					'title' => __('Failed Page'),
					'type' => 'select',
					'options' => $this -> get_pages('Select Page'),
					'description' => "URL of fail page"
				),
				'redirect_cancel_page_id' => array(
					'title' => __('Cancel Page'),
					'type' => 'select',
					'options' => $this -> get_pages('Select Page'),
					'description' => "URL of cancel page"
				)
			);
		}

		public function admin_options(){
			echo '<h3>'.__('WMB SSLCommerz Payment Gateway', 'SSLCommerz').'</h3>';
			echo '<p>'.__('WMB SSLCommerz is most popular payment gateway for online shopping in Bangladesh').'</p>';
			echo '<table class="form-table">';
			// Generate the HTML For the settings form.
			$this -> generate_settings_html();
			echo '</table>';
		}

		/**
		 *  There are no payment fields for WMB, but we want to show the description if set.
		 **/
		function payment_fields(){
			if($this -> description) echo wpautop(wptexturize($this -> description));
		}
		/**
		 * Receipt Page
		 **/
		function receipt_page($order){
			echo '<p>'.__('Thank you for your order, please click the button below to pay with WMB SSLCommerz.', 'SSLCommerz').'</p>';
			echo $this -> generate_WMB_SSLCommerz_form($order);
		}
	
		/**
		 * Get wmb sslcommerz Args for passing to wmb sslcommerz
		**/
		function get_wmb_sslcommerz_args( $order ) {
			global $woocommerce;

			$order_id 		= $order->id;

			$order_total	= $order->get_total();
			$store_id 	= $this -> store_id;
			// $memo        	= "Payment for Order ID: $order_id";
            $notify_url  	= str_replace( 'https:', 'http:', add_query_arg( 'wc-api', 'WC_WMB_SSLCommerz', home_url( '/' ) ) );
			
			$redirect_succ_url = $notify_url;
			$redirect_fail_url = $notify_url;
			$redirect_cancel_url = $notify_url;
			// wmb sslcommerz Args
			$wmb_sslcommerz_args = array(
				'total_amount' => $order -> order_total,
				'store_id' => $store_id,
				//'currency' =>	get_option('woocommerce_currency'),
                'tran_id' => $order_id,
                'success_url' => $redirect_succ_url,
				'fail_url' => $redirect_fail_url,
				'cancel_url' => $redirect_cancel_url,
				'card_name' => 'mtbl',
				'show_all_gw' => '1',
                // 'cus_name' => $order -> billing_first_name .' '. $order -> billing_last_name,
                // 'cus_add1' => $order -> billing_address_1,
                // 'cus_country' => $order -> billing_country,
                // 'cus_state' => $order -> billing_state,
                // 'cus_city' => $order -> billing_city,
                // 'cus_postcode' => $order -> billing_postcode,
                // 'cus_phone'=> $order -> billing_phone,
                // 'cus_email' => $order -> billing_email,
                // 'ship_name' => $order -> shipping_first_name .' '. $order -> shipping_last_name,
                // 'ship_add1' => $order -> shipping_address_1,
                // 'ship_country' => $order -> shipping_country,
                // 'ship_state' => $order -> shipping_state,
                // 'delivery_cust_tel' => '',
                // 'desc' =>  $desc,
                // 'ship_city' => $order -> shipping_city,
                // 'ship_postcode' => $order -> shipping_postcode
				);

			$wmb_sslcommerz_args = apply_filters( 'woocommerce_wmb_sslcommerz_args', $wmb_sslcommerz_args );
			return $wmb_sslcommerz_args;
		}
	
	
		/**
		 * Generate WMB SSLCommerz button link
		 **/
		public function generate_WMB_SSLCommerz_form($order_id){

			global $woocommerce;
			$order = new WC_Order( $order_id );
			//$txnid = $order_id.'_'.date("ymds");
			
			//$wmb_sslcommerz_adr = $this->testurl;
			$wmb_sslcommerz_adr = $this->liveurl;

			$wmb_sslcommerz_args = $this->get_wmb_sslcommerz_args( $order );

			$wmb_sslcommerz_args_array = array();

			foreach ($wmb_sslcommerz_args as $key => $value) {
				$wmb_sslcommerz_args_array[] = '<input type="hidden" name="'.esc_attr( $key ).'" value="'.esc_attr( $value ).'" />';
			}
				
			return '<form action="'.esc_url( $wmb_sslcommerz_adr ).'" method="post" id="payment_gw" name="payment_gw" target="_top">
					' . implode('', $wmb_sslcommerz_args_array) . '
					<input type="submit" id="submit_WMB_payment_form" class="button button-alt" name="submit" value="Pay Now" /><a class="button cancel" href="'.$order->get_cancel_order_url().'">'.__('Cancel order &amp; restore cart', 'SSLCommerz').'</a>
			</form>';
		}
		/**
		 * Process the payment and return the result
		 **/
		function process_payment($order_id){
			global $woocommerce;
			$order = new WC_Order( $order_id );
			return array(
				'result' => 'success',
				'redirect'	=> $order->get_checkout_payment_url( true )
			);
		}

		/**
		 * Check for valid WMB server callback
		 **/
		function check_WMB_SSLCommerz_response(){
			global $woocommerce;
			if(isset($_REQUEST['tran_id']) && isset($_REQUEST['val_id'])){
				$order_id = trim($_REQUEST['tran_id']);
				$val_id = trim($_REQUEST['val_id']);
				$amount = $_REQUEST['amount'];
				$card_type = $_REQUEST['card_type'];
				$store_amount = $_REQUEST['store_amount'];
				$bank_tran_id = $_REQUEST['bank_tran_id'];
				if($order_id != ''){
					try{
						$order = new WC_Order( $order_id );
						$wmb_sett = get_option( 'woocommerce_wmb_sslcommerz_settings' );
						$store_id = trim($wmb_sett['store_id']); 
						$store_passwd = trim($wmb_sett['store_pass']); 
						
						//$client = new SoapClient("https://www.sslcommerz.com.bd/validator/api/testbox/validationserverAPI.php?wsdl", array( 'location' => "	https://www.sslcommerz.com.bd/validator/api/testbox/validationserverAPI.php?wsdl", ) );
						
						$client = new SoapClient("https://www.sslcommerz.com.bd/validator/api/testbox/validationserverAPI.php?wsdl", array( 'location' => "https://www.sslcommerz.com.bd:443/validator/api/testbox/validationserverAPI.php", ) );
						//$client = new SoapClient("https://www.sslcommerz.com.bd/validator/api/validationserverAPI.php?wsdl", array( 'location' => "https://www.sslcommerz.com.bd:443/validator/api/validationserverAPI.php", ) );
						
						$result = $client->checkValidation($val_id, $store_id, $store_passwd);
						
						$result = json_decode($result);
						
						$status = $result->status;
					   
						$transauthorised = false;
						if($order->post_status !=='completed'){
							if($status == 'VALID' || $status == 'VALIDATED'){
								$transauthorised = true;
								$this -> msg['message'] = "Thank you for shopping with us. Your account has been charged and your transaction is successful. We will be shipping your order to you soon.";
								$this -> msg['class'] = 'woocommerce_message';
								if($order->post_status == 'processing'){
									
								}else{
									$order->payment_complete();
									global $wpdb;
									$tran_id = $result->tran_id;
									$order_item_id = $wpdb->get_var("SELECT order_item_id FROM ".$wpdb->prefix."woocommerce_order_items WHERE order_id='$tran_id' ORDER BY order_item_id ASC LIMIT 1");
									$val_id = $result->val_id; 
									$amount = $result->amount;
									$store_amount = $result->store_amount; 
									$bank_tran_id = $result->bank_tran_id; 
									$card_type = $result->card_type;
									$tran_date = $result->tran_date;
									$validated_on = $result->validated_on;
									woocommerce_add_order_item_meta( $order_item_id,'val_id',$val_id);
									woocommerce_add_order_item_meta( $order_item_id,'amount',$amount);
									woocommerce_add_order_item_meta( $order_item_id,'store_amount',$store_amount);
									woocommerce_add_order_item_meta( $order_item_id,'bank_tran_id',$bank_tran_id);
									woocommerce_add_order_item_meta( $order_item_id,'card_type',$card_type);
									woocommerce_add_order_item_meta( $order_item_id,'tran_date',$tran_date);
									woocommerce_add_order_item_meta( $order_item_id,'validated_on',$validated_on);
									# ISSUER INFO 
									$card_no = $result->card_no; 
									$card_issuer = $result->card_issuer; 
									$card_brand = $result->card_brand;
									$card_issuer_country = $result->card_issuer_country; 
									$card_issuer_country_code = $result->card_issuer_country_code;
									woocommerce_add_order_item_meta( $order_item_id,'card_no',$card_no);
									woocommerce_add_order_item_meta( $order_item_id,'card_issuer',$card_issuer);
									woocommerce_add_order_item_meta( $order_item_id,'card_brand',$card_brand);
									woocommerce_add_order_item_meta( $order_item_id,'card_issuer_country',$card_issuer_country);
									woocommerce_add_order_item_meta( $order_item_id,'card_issuer_country_code',$card_issuer_country_code);
									
									$order -> add_order_note('WMB payment successful<br/>Unique Bank trans id is: '.$_REQUEST['bank_tran_id']);
									$order -> add_order_note($this->msg['message']);
									$woocommerce->cart->empty_cart();
								}
							}else{
								$this -> msg['class'] = 'woocommerce_error';
								$this -> msg['message'] = "Thank you for shopping with us. However, the transaction has been declined.";
								$order->add_order_note('Transaction Declined: '.$_REQUEST['Error']);
								
							}
							add_action('the_content', array(&$this, 'showMessage'));
						}
					}catch(Exception $e){ 
						$msg = "Error";
					}
				}
				$redirect_succ_url = ($this -> redirect_success_page_id=="" || $this -> redirect_success_page_id==0)?get_site_url() . "/":get_permalink($this -> redirect_success_page_id);
				
				$redirect_succ_url = add_query_arg( array('msg'=> urlencode($this -> msg['message']), 'type'=>$this -> msg['class']), $redirect_succ_url );
				wp_redirect( $redirect_succ_url );
				exit;
			}elseif(isset($_REQUEST['error']) && $_REQUEST['error'] == 'Cancelled by User'){
				$this -> msg['class'] = 'error';
				$this -> msg['message'] = "Thank you for shopping with us. However, the transaction has been cancelled.";
				$order = new WC_Order($tran_id);
				$order->update_status('cancelled', 'Cancelled by User.');
				add_action('the_content', array(&$this, 'showMessage'));
				
				$redirect_cancel_url = ($this -> redirect_cancel_page_id=="" || $this -> redirect_cancel_page_id==0)?get_site_url() . "/":get_permalink($this -> redirect_cancel_page_id);
				$redirect_cancel_url = add_query_arg( array('msg'=> urlencode($this -> msg['message']), 'type'=>$this -> msg['class']), $redirect_cancel_url );
				wp_redirect( $redirect_cancel_url );
				exit;
			}else{
				$tran_id = $_REQUEST['tran_id'];
				$error = $_REQUEST['error'];
				$order = new WC_Order($tran_id);
				$order->update_status('failed', $error);
				
				$this -> msg['class'] = 'error';
				$this -> msg['message'] = "Thank you for shopping with us. However, the transaction has been Failed.";
				add_action('the_content', array(&$this, 'showMessage'));
				
				$redirect_fail_url = ($this -> redirect_fail_page_id=="" || $this -> redirect_fail_page_id==0)?get_site_url() . "/":get_permalink($this -> redirect_fail_page_id);
				$redirect_fail_url = add_query_arg( array('msg'=> urlencode($this -> msg['message']), 'type'=>$this -> msg['class']), $redirect_fail_url );
				wp_redirect( $redirect_fail_url );
				exit;
			}

		}

		function showMessage($content){
			return '<div class="box '.$this -> msg['class'].'-box">'.$this -> msg['message'].'</div>'.$content;
		}
		// get all pages
		function get_pages($title = false, $indent = true) {
			$wp_pages = get_pages('sort_column=menu_order');
			$page_list = array();
			if ($title) $page_list[] = $title;
			foreach ($wp_pages as $page) {
				$prefix = '';
				// show indented child pages?
				if ($indent) {
					$has_parent = $page->post_parent;
					while($has_parent) {
						$prefix .=  ' - ';
						$next_page = get_page($has_parent);
						$has_parent = $next_page->post_parent;
					}
				}
				// add to page list array array
				$page_list[$page->ID] = $prefix . $page->post_title;
			}
			return $page_list;
		}
	}
   /**
     * Add the Gateway to WooCommerce
     **/
    function woocommerce_add_SSLCommerz_WMB_gateway($methods) {
        $methods[] = 'WC_WMB_SSLCommerz';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_SSLCommerz_WMB_gateway' );
}
